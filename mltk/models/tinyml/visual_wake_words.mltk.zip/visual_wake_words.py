__mltk_version__ = '0.3.0'

"""visual_wake_words
**********************

Visual Wakeword - Person detection (MobileNetv1 with COCO14)

See this model's specification on Github: `vww_model.py <https://github.com/mlcommons/tiny/blob/master/benchmark/training/visual_wake_words/vww_model.py>`_.

Taken from:

* https://github.com/mlcommons/tiny/blob/master/benchmark/training/visual_wake_words
* https://github.com/SiliconLabs/platform_ml_models/tree/master/eembc/Person_detection


Dataset
----------
* MSCOCO14 based [https://cocodataset.org/#download]
* Extraction based on COCO API [https://github.com/cocodataset/cocoapi]
* Person mimimal bounding box 2.5%
* 96x96 images resized with antialias filtering, no aspect ratio preservation
* All images converted to RGB
* Training and validation sets combined
* Dataset generation script (buildPersonDetectionDatabase.py) is included in repo
* Extracted Reference Dataset: `vw_coco2014_96.tar.gz <https://www.silabs.com/public/files/github/machine_learning/benchmarks/datasets/vw_coco2014_96.tar.gz>`_

Model Topology
----------------
* Based on https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet_v1.md
* Chosen configuration is a MobileNet_v1_0.25_96


Performance (floating point model) 
-----------------------------------
* Accuracy - 85.4%
* AUC - .931

Performance (quantized tflite model) 
------------------------------------
* Accuracy - 85.0%
* AUC - .928

"""

from mltk.core.preprocess.image.parallel_generator import ParallelImageDataGenerator
from mltk.core.model import (
    MltkModel,
    TrainMixin,
    ImageDatasetMixin,
    EvaluateClassifierMixin
)
from mltk.models.shared import MobileNetV1
from mltk.datasets.image.mscoco14 import mscoco14_preprocessed_v1


# Instantiate the MltkModel object with the following 'mixins':
# - TrainMixin            - Provides classifier model training operations and settings
# - ImageDatasetMixin     - Provides image data generation operations and settings
# - EvaluateClassifierMixin         - Provides classifier evaluation operations and settings
# @mltk_model   # NOTE: This tag is required for this model be discoverable
class MyModel(
    MltkModel, 
    TrainMixin, 
    ImageDatasetMixin, 
    EvaluateClassifierMixin
):
    pass
my_model = MyModel()

#################################################
# General parameters
my_model.version = 1
my_model.description = 'TinyML: Visual Wake Words - MobileNetv1 with COCO14'

#################################################
# Training parameters
my_model.epochs = 50
my_model.batch_size = 50 
my_model.optimizer = 'adam'
my_model.metrics = ['accuracy']
my_model.loss = 'categorical_crossentropy'


#################################################
# Image Dataset Settings

# The directory of the training data
my_model.dataset = mscoco14_preprocessed_v1
# The classification type
my_model.class_mode = 'categorical'
# The class labels found in your training dataset directory
my_model.classes = mscoco14_preprocessed_v1.CLASSES
# The input shape to the model. The dataset samples will be resized if necessary
my_model.input_shape = mscoco14_preprocessed_v1.INPUT_SHAPE

validation_split = 0.1


##############################################################
# Training callbacks
#

# Learning rate schedule
def lr_schedule(epoch):
    lrate = 0.001
    if epoch > 20:
        lrate = 0.0005
    if epoch > 30:
        lrate = 0.00025
    return lrate

my_model.lr_schedule = dict(
    schedule = lr_schedule,
    verbose = 1
)

my_model.datagen = ParallelImageDataGenerator(
    cores=.35,
    max_batches_pending=32,
    rotation_range=10,
    width_shift_range=0.05,
    height_shift_range=0.05,
    zoom_range=.1,
    horizontal_flip=True,
    validation_split=validation_split
)



##############################################################
# Model Layout
def my_model_builder(model: MyModel):
    keras_model = MobileNetV1(
        input_shape=model.input_shape
    )
    keras_model.compile(
        loss=model.loss, 
        optimizer=model.optimizer, 
        metrics=model.metrics
    )
    return keras_model

my_model.build_model_function = my_model_builder